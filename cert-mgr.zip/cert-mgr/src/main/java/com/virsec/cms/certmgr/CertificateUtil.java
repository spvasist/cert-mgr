package com.virsec.cms.certmgr;

import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.*;
import org.bouncycastle.cert.*;
import org.bouncycastle.cert.jcajce.*;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.bc.BcDigestCalculatorProvider;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;
import org.springframework.util.CollectionUtils;

import javax.security.auth.x500.X500Principal;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import static com.virsec.cms.certmgr.CertMgrApplication.KEY_SIZE;

public class CertificateUtil {
    static AtomicLong startingSerialNumber = new AtomicLong(System.currentTimeMillis());
    public static final String HASH_ALG = "SHA256withRSA";

    public static CmsCertificate generateRootCA(String cn, List<String> sanList, int validityInDays) throws Exception {
        KeyPairGenerator rsa = KeyPairGenerator.getInstance("RSA");
        rsa.initialize(KEY_SIZE);
        KeyPair keyPair = rsa.generateKeyPair();
        X509Certificate certificate = generateRootCA(keyPair, "SHA256withRSA", cn, sanList, validityInDays);
        return new CmsCertificate(keyPair.getPrivate(), keyPair.getPrivate().getEncoded(), certificate);
    }

    public static X509Certificate generateRootCA(KeyPair keyPair, String hashAlgorithm, String cn, List<String> sanList, int days) throws Exception {
        Instant now = Instant.now();
        Date notBefore = Date.from(now);
        Date notAfter = Date.from(now.plus(Duration.ofDays(days)));
        X500Name x500Name = new X500Name("CN=" + cn);
        X509v3CertificateBuilder certificateBuilder =
                new JcaX509v3CertificateBuilder(x500Name, BigInteger.valueOf(now.toEpochMilli()), notBefore, notAfter, x500Name, keyPair.getPublic())
                        .addExtension(Extension.subjectKeyIdentifier, false, createSubjectKeyId(keyPair.getPublic()))
                        .addExtension(Extension.authorityKeyIdentifier, false, createAuthorityKeyId(keyPair.getPublic()))
                        .addExtension(Extension.basicConstraints, true, new BasicConstraints(3));

        addSanList(sanList, certificateBuilder);
        ContentSigner contentSigner = new JcaContentSignerBuilder(hashAlgorithm).build(keyPair.getPrivate());
        X509CertificateHolder certificateHolder = certificateBuilder.build(contentSigner);
        return new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider()).getCertificate(certificateHolder);
    }

    /**
     * Creates the hash value of the public key.
     *
     * @param publicKey of the certificate
     * @return SubjectKeyIdentifier hash
     * @throws OperatorCreationException
     */
    private static SubjectKeyIdentifier createSubjectKeyId(final PublicKey publicKey) throws OperatorCreationException {
        final SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfo.getInstance(publicKey.getEncoded());
        final DigestCalculator digCalc = new BcDigestCalculatorProvider().get(new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1));
        return new X509ExtensionUtils(digCalc).createSubjectKeyIdentifier(publicKeyInfo);
    }

    /**
     * Creates the hash value of the authority public key.
     *
     * @param publicKey of the authority certificate
     * @return AuthorityKeyIdentifier hash
     * @throws OperatorCreationException
     */
    private static AuthorityKeyIdentifier createAuthorityKeyId(final PublicKey publicKey) throws OperatorCreationException {
        final SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfo.getInstance(publicKey.getEncoded());
        final DigestCalculator digCalc = new BcDigestCalculatorProvider().get(new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1));
        return new X509ExtensionUtils(digCalc).createAuthorityKeyIdentifier(publicKeyInfo);
    }


    public static X509Certificate generateSignedCertificate(String cn,
                                                            List<String> sanList,
                                                            int validityInDays,
                                                            X509Certificate signerCert,
                                                            PrivateKey signerKey,
                                                            String sigAlg,
                                                            PublicKey certPublicKey,
                                                            boolean ca) throws
            IOException, OperatorCreationException, CertificateException {

        X500Principal subject = new X500Principal("CN=" + cn);

        final Instant now = Instant.now();
        final Date notBefore = Date.from(now);
        final Date notAfter = Date.from(now.plus(Duration.ofDays(validityInDays)));

        X509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
                signerCert.getSubjectX500Principal(),
                BigInteger.valueOf(startingSerialNumber.incrementAndGet()),
                notBefore,
                notAfter,
                subject,
                certPublicKey);
        if (ca) {
            certBuilder.addExtension(Extension.basicConstraints, true, new BasicConstraints(2));
        } else {
            certBuilder.addExtension(Extension.basicConstraints, true, new BasicConstraints(false));
        }

        certBuilder.addExtension(Extension.subjectKeyIdentifier, false, createSubjectKeyId(certPublicKey))
                .addExtension(Extension.authorityKeyIdentifier, false, createAuthorityKeyId(signerCert.getPublicKey()));
        ExtendedKeyUsage keyUsage;
        if (ca) {
            keyUsage =
                    new ExtendedKeyUsage(new KeyPurposeId[]{KeyPurposeId.id_kp_codeSigning, KeyPurposeId.anyExtendedKeyUsage, KeyPurposeId.id_kp_OCSPSigning,
                            KeyPurposeId.id_kp_clientAuth, KeyPurposeId.id_kp_serverAuth});
            certBuilder.addExtension(Extension.keyUsage, true, new KeyUsage(KeyUsage.digitalSignature | KeyUsage.keyCertSign | KeyUsage.cRLSign));
        } else {
            keyUsage = new ExtendedKeyUsage(new KeyPurposeId[]{KeyPurposeId.id_kp_clientAuth, KeyPurposeId.id_kp_serverAuth});
            certBuilder.addExtension(Extension.keyUsage, true, new KeyUsage(KeyUsage.digitalSignature));
        }
        certBuilder.addExtension(Extension.extendedKeyUsage, false, keyUsage.getEncoded());

        addSanList(sanList, certBuilder);
        ContentSigner signer = new JcaContentSignerBuilder(sigAlg).setProvider(new BouncyCastleProvider()).build(signerKey);
        JcaX509CertificateConverter converter = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider());
        return converter.getCertificate(certBuilder.build(signer));
    }

    private static void addSanList(List<String> sanList, X509v3CertificateBuilder certBuilder) throws CertIOException {
        if (!CollectionUtils.isEmpty(sanList)) {
            List<GeneralName> names = new ArrayList<>();
            sanList.forEach(s -> names.add(new GeneralName(GeneralName.dNSName, s)));
            GeneralNames san = new GeneralNames(names.toArray(new GeneralName[0]));
            certBuilder.addExtension(Extension.subjectAlternativeName, true, san);
        }
    }

    public static PublicKey getPublicKeyFromBytes(byte[] data) throws NoSuchAlgorithmException, InvalidKeySpecException {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(data);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA", new BouncyCastleProvider());
        return keyFactory.generatePublic(spec);
    }

    public static PrivateKey getPrivateKeyFromBytes(byte[] data) throws NoSuchAlgorithmException, InvalidKeySpecException {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(data);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(spec);
    }

    public static void exportPem(String header, List<byte[]> list, String fileName) throws IOException {
        PemWriter pemWriter = new PemWriter(new OutputStreamWriter(new FileOutputStream(fileName)));
        try {
            for (byte[] data : list) {
                PemObject pemObject = new PemObject(header, data);
                pemWriter.writeObject(pemObject);
            }
        } finally {
            pemWriter.close();
        }
    }


    public static X509CRL createEmptyCRL(PrivateKey caKey, String sigAlg, X509Certificate caCert)
            throws IOException, GeneralSecurityException, OperatorCreationException {
        X509v2CRLBuilder crlGen = new JcaX509v2CRLBuilder(caCert.getSubjectX500Principal(), new Date(System.currentTimeMillis()));
        crlGen.setNextUpdate(new Date(System.currentTimeMillis() + (24 * 60 * 60 * 1000)));
        // add extensions to CRL
        JcaX509ExtensionUtils extUtils = new JcaX509ExtensionUtils();
        crlGen.addExtension(Extension.authorityKeyIdentifier, false, extUtils.createAuthorityKeyIdentifier(caCert));
        ContentSigner signer = new JcaContentSignerBuilder(sigAlg).setProvider(new BouncyCastleProvider()).build(caKey);
        JcaX509CRLConverter converter = new JcaX509CRLConverter().setProvider(new BouncyCastleProvider());
        return converter.getCRL(crlGen.build(signer));
    }

    public static X509CRL addRevocationToCRL(PrivateKey caKey, String sigAlg, X509CRL crl, X509Certificate certToRevoke)
            throws IOException, GeneralSecurityException, OperatorCreationException {
        X509v2CRLBuilder crlGen = new JcaX509v2CRLBuilder(crl);
        crlGen.setNextUpdate(new Date(System.currentTimeMillis() + (24 * 60 * 60 * 1000)));
        // add revocation
        ExtensionsGenerator extGen = new ExtensionsGenerator();
        CRLReason crlReason = CRLReason.lookup(CRLReason.privilegeWithdrawn);
        extGen.addExtension(Extension.reasonCode, false, crlReason.getEncoded());
        crlGen.addCRLEntry(certToRevoke.getSerialNumber(), new Date(), extGen.generate());
        ContentSigner signer = new JcaContentSignerBuilder(sigAlg).setProvider(new BouncyCastleProvider()).build(caKey);
        JcaX509CRLConverter converter = new JcaX509CRLConverter().setProvider(new BouncyCastleProvider());
        return converter.getCRL(crlGen.build(signer));
    }
}
