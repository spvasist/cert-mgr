package com.virsec.cms.certmgr;

import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.*;
import org.bouncycastle.asn1.x509.CRLReason;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.cert.*;
import org.bouncycastle.cert.jcajce.*;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DigestCalculator;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.bc.BcDigestCalculatorProvider;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.security.auth.x500.X500Principal;
import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import static com.virsec.cms.certmgr.CertificateUtil.HASH_ALG;

@SpringBootApplication
public class CertMgrApplication {
    public static CmsCertificate ROOT_CA;
    public static CmsCertificate IM_CA;
    public static String VIRSEC_ROOT_CA = "virsec-root-ca";
    public static String VIRSEC_IM_CA = "virsec-im-ca";
    public static String ROOT_CA_KEY_STORE_PATH = "virsec-root-ca.p12";
    public static String IM_CA_KEY_STORE_PATH = "virsec-im-ca.p12";
    public static String KEY_STORE_PASSWORD = "123456";
    public static int KEY_SIZE = 2048;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(CertMgrApplication.class, args);
        //run();
        //ROOT_CA = CertificateUtil.generateRootCA("Virsec Root CA", List.of("server.cms.virsec.com"), 365);
        CertificateStoreUtil.initCA();
        Files.write(Paths.get("certs\\cms-root-ca.crt"), ROOT_CA.getCertificate().getEncoded());
        Files.write(Paths.get("certs\\cms-im-ca.crt"), IM_CA.getCertificate().getEncoded());
        tryCsr();
    }

    private static void tryCsr() throws Exception {
        KeyPairGenerator pairGen = KeyPairGenerator.getInstance("RSA");
        pairGen.initialize(KEY_SIZE);
        KeyPair pair = pairGen.generateKeyPair();
        PKCS10CertificationRequestBuilder p10Builder = new JcaPKCS10CertificationRequestBuilder(
                new X500Principal("CN=client.cms.virsec.com"), pair.getPublic());
        JcaContentSignerBuilder csBuilder = new JcaContentSignerBuilder(HASH_ALG);
        ContentSigner signer = csBuilder.build(pair.getPrivate());
        PKCS10CertificationRequest csr = p10Builder.build(signer);
        Files.write(Paths.get("certs\\cms-csr.csr"), csr.getEncoded());
    }

    private static void run() throws Exception {
        KeyPairGenerator rsa = KeyPairGenerator.getInstance("RSA");
        rsa.initialize(KEY_SIZE);
        KeyPair keyPair = rsa.generateKeyPair();
        X509Certificate caCert = generate(keyPair, "SHA256withRSA", "*.virsec.com", 365);
        byte[] encoded = caCert.getEncoded();
        Files.write(Paths.get("cms-ca.crt"), encoded);
        Files.write(Paths.get("cms-ca.key"), keyPair.getPrivate().getEncoded());
        KeyPair endKeyPair = rsa.generateKeyPair();
        X509Certificate endCert = generateEndCertificate(caCert, keyPair.getPrivate(), "SHA256withRSA", endKeyPair.getPublic());
        Files.write(Paths.get("cms-end.crt"), endCert.getEncoded());

        X509CRL emptyCRL = createEmptyCRL(keyPair.getPrivate(), "SHA256withRSA", caCert);
        Files.write(Paths.get("empty-crl.crl"), emptyCRL.getEncoded());

        X509CRL newCrl = addRevocationToCRL(keyPair.getPrivate(), "SHA256withRSA", emptyCRL, endCert);

        Files.write(Paths.get("new-crl.crl"), newCrl.getEncoded());

        exportPem("CERTIFICATE", List.of(caCert.getEncoded()), "cms-ca1.pem");
        exportPem("RSA PRIVATE KEY", List.of(keyPair.getPrivate().getEncoded()), "cms-ca1.key");
        exportPem("CERTIFICATE", List.of(endCert.getEncoded(), caCert.getEncoded()), "cms-bundle1.pem");
        exportPem("RSA PRIVATE KEY", List.of(endKeyPair.getPrivate().getEncoded()), "cms-bundle1.key");
        System.out.println("---- DONE ----");

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(ROOT_CA.getPrivateKeyEncoded());
        PrivateKey privateKey = KeyFactory.getInstance("RSA").generatePrivate(spec);
        //ROOT_CA.getCertificate().getEncoded()
        X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(ROOT_CA.getCertificate().getPublicKey().getEncoded());
        PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(pubSpec);
        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
        InputStream in = new ByteArrayInputStream(ROOT_CA.getCertificate().getEncoded());
        X509Certificate cert = (X509Certificate) certFactory.generateCertificate(in);

        //        PKCS10CertificationRequestBuilder p10Builder = new JcaPKCS10CertificationRequestBuilder(
        //                new X500Principal("CN=Requested Test Certificate"), pair.getPublic());
        //        JcaContentSignerBuilder csBuilder = new JcaContentSignerBuilder("SHA256withRSA");
        //        ContentSigner signer = csBuilder.build(pair.getPrivate());
        //        PKCS10CertificationRequest csr = p10Builder.build(signer);
    }

    private static void exportPem(String header, List<byte[]> list, String fileName) throws CertificateEncodingException, IOException {

        PemWriter pemWriter = new PemWriter(new OutputStreamWriter(new FileOutputStream(fileName)));
        try {
            for (byte[] data : list) {
                PemObject pemObject = new PemObject(header, data);
                pemWriter.writeObject(pemObject);
            }
        } finally {
            pemWriter.close();
        }
    }

    public static X509Certificate generate(final KeyPair keyPair,
                                           final String hashAlgorithm,
                                           final String cn,
                                           final int days)
            throws OperatorCreationException, CertificateException, CertIOException {
        final Instant now = Instant.now();
        final Date notBefore = Date.from(now);
        final Date notAfter = Date.from(now.plus(Duration.ofDays(days)));
        final ContentSigner contentSigner = new JcaContentSignerBuilder(hashAlgorithm).build(keyPair.getPrivate());
        final X500Name x500Name = new X500Name("CN=" + cn);
        GeneralName cmsCommonName = new GeneralName(GeneralName.dNSName, "cms.virsec.com");
        GeneralName intCmsCommonName = new GeneralName(GeneralName.dNSName, "int.cms.virsec.com");
        GeneralNames subjectAltName = new GeneralNames(new GeneralName[]{cmsCommonName, intCmsCommonName});
        final X509v3CertificateBuilder certificateBuilder =
                new JcaX509v3CertificateBuilder(x500Name,
                        BigInteger.valueOf(now.toEpochMilli()),
                        notBefore,
                        notAfter,
                        x500Name,
                        keyPair.getPublic())
                        .addExtension(Extension.subjectKeyIdentifier, false, createSubjectKeyId(keyPair.getPublic()))
                        .addExtension(Extension.authorityKeyIdentifier, false, createAuthorityKeyId(keyPair.getPublic()))
                        .addExtension(Extension.basicConstraints, true, new BasicConstraints(true))
                        .addExtension(Extension.subjectAlternativeName, true, subjectAltName);
        //.addExtension(Extension.cRLDistributionPoints, true, "http://127.0.0.1:8080/virsec.clr".getBytes(StandardCharsets.UTF_8));
        X509CertificateHolder certificateHolder = certificateBuilder.build(contentSigner);
        return new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider()).getCertificate(certificateHolder);
    }

    /**
     * Creates the hash value of the public key.
     *
     * @param publicKey of the certificate
     * @return SubjectKeyIdentifier hash
     * @throws OperatorCreationException
     */
    private static SubjectKeyIdentifier createSubjectKeyId(final PublicKey publicKey) throws OperatorCreationException {
        final SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfo.getInstance(publicKey.getEncoded());
        final DigestCalculator digCalc =
                new BcDigestCalculatorProvider().get(new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1));

        return new X509ExtensionUtils(digCalc).createSubjectKeyIdentifier(publicKeyInfo);
    }

    /**
     * Creates the hash value of the authority public key.
     *
     * @param publicKey of the authority certificate
     * @return AuthorityKeyIdentifier hash
     * @throws OperatorCreationException
     */
    private static AuthorityKeyIdentifier createAuthorityKeyId(final PublicKey publicKey)
            throws OperatorCreationException {
        final SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfo.getInstance(publicKey.getEncoded());
        final DigestCalculator digCalc =
                new BcDigestCalculatorProvider().get(new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1));

        return new X509ExtensionUtils(digCalc).createAuthorityKeyIdentifier(publicKeyInfo);
    }

    public static X509Certificate generateEndCertificate(
            X509Certificate signerCert, PrivateKey signerKey,
            String sigAlg, PublicKey certKey)
            throws CertIOException, OperatorCreationException, CertificateException {
        X500Principal subject = new X500Principal("CN=server.cms.virsec.com");


        X509v3CertificateBuilder certBldr = new JcaX509v3CertificateBuilder(
                signerCert.getSubjectX500Principal(),
                calculateSerialNumber(),
                calculateDate(0),
                calculateDate(24 * 31),
                subject,
                certKey);


        GeneralNames subjectAltName = new GeneralNames(new GeneralName[]{new GeneralName(GeneralName.dNSName, "*.cms.virsec.com")});
        certBldr.addExtension(Extension.basicConstraints, true, new BasicConstraints(false))
                .addExtension(Extension.subjectAlternativeName, true, subjectAltName)
                .addExtension(Extension.keyUsage, true, new KeyUsage(KeyUsage.digitalSignature));


        ContentSigner signer = new JcaContentSignerBuilder(sigAlg).setProvider(new BouncyCastleProvider()).build(signerKey);

        JcaX509CertificateConverter converter = new JcaX509CertificateConverter().setProvider(new BouncyCastleProvider());


        return converter.getCertificate(certBldr.build(signer));
    }

    /**
     * Calculate a date in seconds (suitable for the PKIX profile - RFC 5280)
     *
     * @param hoursInFuture hours ahead of now, may be negative.
     * @return a Date set to now + (hoursInFuture * 60 * 60) seconds
     */
    public static Date calculateDate(int hoursInFuture) {
        long secs = System.currentTimeMillis() / 1000;
        return new Date((secs + ((long) hoursInFuture * 60 * 60)) * 1000);
    }

    private static final AtomicLong serialNumberBase = new AtomicLong(System.currentTimeMillis());


    /**
     * Calculate a serial number using a monotonically increasing value.
     *
     * @return a BigInteger representing the next serial number in the sequence.
     */
    public static synchronized BigInteger calculateSerialNumber() {
        return BigInteger.valueOf(serialNumberBase.incrementAndGet());
    }

    public static X509CRL createEmptyCRL(PrivateKey caKey, String sigAlg, X509Certificate caCert)
            throws IOException, GeneralSecurityException, OperatorCreationException {
        X509v2CRLBuilder crlGen = new JcaX509v2CRLBuilder(caCert.getSubjectX500Principal(), calculateDate(0));
        crlGen.setNextUpdate(calculateDate(24 * 7));
        // add extensions to CRL
        JcaX509ExtensionUtils extUtils = new JcaX509ExtensionUtils();
        crlGen.addExtension(Extension.authorityKeyIdentifier, false, extUtils.createAuthorityKeyIdentifier(caCert));
        ContentSigner signer = new JcaContentSignerBuilder(sigAlg).setProvider(new BouncyCastleProvider()).build(caKey);
        JcaX509CRLConverter converter = new JcaX509CRLConverter().setProvider(new BouncyCastleProvider());
        return converter.getCRL(crlGen.build(signer));
    }

    public static X509CRL addRevocationToCRL(PrivateKey caKey, String sigAlg, X509CRL crl, X509Certificate certToRevoke)
            throws IOException, GeneralSecurityException, OperatorCreationException {
        X509v2CRLBuilder crlGen = new JcaX509v2CRLBuilder(crl);
        crlGen.setNextUpdate(calculateDate(24 * 7));
        // add revocation
        ExtensionsGenerator extGen = new ExtensionsGenerator();
        CRLReason crlReason = CRLReason.lookup(CRLReason.privilegeWithdrawn);
        extGen.addExtension(Extension.reasonCode, false, crlReason.getEncoded());
        crlGen.addCRLEntry(certToRevoke.getSerialNumber(), new Date(), extGen.generate());
        ContentSigner signer = new JcaContentSignerBuilder(sigAlg).setProvider(new BouncyCastleProvider()).build(caKey);
        JcaX509CRLConverter converter = new JcaX509CRLConverter().setProvider(new BouncyCastleProvider());
        return converter.getCRL(crlGen.build(signer));
    }


}
