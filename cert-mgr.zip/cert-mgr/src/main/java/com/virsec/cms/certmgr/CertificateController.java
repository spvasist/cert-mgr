package com.virsec.cms.certmgr;

import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PublicKey;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.security.spec.RSAPublicKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import static com.virsec.cms.certmgr.CertMgrApplication.*;
import static com.virsec.cms.certmgr.CertificateUtil.*;

@RestController
public class CertificateController {
    @GetMapping("/generate-certs")
    public void generateCerts() throws Exception {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(KEY_SIZE);
        KeyPair intermediateKeyPair = keyPairGenerator.generateKeyPair();
        X509Certificate intermediateCa =
                CertificateUtil.generateSignedCertificate("CN=Virsec Intermediate CA", List.of("server.cms.virsec.com", "*.cms.virsec.com"), 365,
                        ROOT_CA.getCertificate(),
                        ROOT_CA.getPrivateKey(), CertificateUtil.HASH_ALG, intermediateKeyPair.getPublic(), true, true);

        Files.write(Paths.get("certs", "cms-intermediate-ca.crt"), intermediateCa.getEncoded());
        KeyPair serverKeyPair = keyPairGenerator.generateKeyPair();
        X509Certificate serverCertificate =
                CertificateUtil.generateSignedCertificate("CN=server.cms.virsec.com", List.of("server.cms.virsec.com"), 365, intermediateCa,
                        intermediateKeyPair.getPrivate(), CertificateUtil.HASH_ALG, serverKeyPair.getPublic(), false, true);
        KeyPair clientKeyPair = keyPairGenerator.generateKeyPair();
        X509Certificate clientCertificate =
                CertificateUtil.generateSignedCertificate("CN=client.cms.virsec.com", List.of("client.cms.virsec.com"), 365, intermediateCa,
                        intermediateKeyPair.getPrivate(), CertificateUtil.HASH_ALG, clientKeyPair.getPublic(), false, false);
        Files.write(Paths.get("certs", "cms-server-cert.crt"), serverCertificate.getEncoded());

        exportPem(PEMParser.TYPE_CERTIFICATE, List.of(intermediateCa.getEncoded(), ROOT_CA.getCertificate().getEncoded()), "certs\\cms-bundle-ca.pem");
        exportPem(PEMParser.TYPE_CERTIFICATE, List.of(serverCertificate.getEncoded(), intermediateCa.getEncoded(), ROOT_CA.getCertificate().getEncoded()),
                "certs\\cms-bundle-server.pem");
        exportPem(PEMParser.TYPE_RSA_PRIVATE_KEY, List.of(serverKeyPair.getPrivate().getEncoded()), "certs\\cms-bundle-server.key");
        Files.write(Paths.get("certs", "cms-bundle-raw.key"), serverKeyPair.getPrivate().getEncoded());

        exportPem(PEMParser.TYPE_CERTIFICATE, List.of(clientCertificate.getEncoded()), "certs\\cms-client.pem");
        exportPem(PEMParser.TYPE_RSA_PRIVATE_KEY, List.of(clientKeyPair.getPrivate().getEncoded()), "certs\\cms-client.key");

        X509CRL emptyRootCaCRL = CertificateUtil.createEmptyCRL(ROOT_CA.getPrivateKey(), HASH_ALG, ROOT_CA.getCertificate());
        exportPem(PEMParser.TYPE_X509_CRL, List.of(emptyRootCaCRL.getEncoded()), "certs\\cms-bundle-rca.crl");

        X509CRL emptyCRL = CertificateUtil.createEmptyCRL(intermediateKeyPair.getPrivate(), HASH_ALG, intermediateCa);
        X509CRL crl = CertificateUtil.addRevocationToCRL(intermediateKeyPair.getPrivate(), HASH_ALG, emptyCRL, clientCertificate);
        exportPem(PEMParser.TYPE_X509_CRL, List.of(crl.getEncoded()), "certs\\cms-bundle-ica.crl");

        CertificateStoreUtil.createP12KeyStore("server", serverKeyPair.getPrivate(),
                new X509Certificate[]{serverCertificate, intermediateCa, ROOT_CA.getCertificate()}, "certs\\" + "cms-bundle-server.p12");
        CertificateStoreUtil.createP12TrustStore("ca", new X509Certificate[]{intermediateCa, ROOT_CA.getCertificate()},
                "certs\\" + "cms-bundle-ca.p12");
        CertificateStoreUtil.createP12KeyStore("client", clientKeyPair.getPrivate(),
                new X509Certificate[]{clientCertificate, intermediateCa, ROOT_CA.getCertificate()}, "certs\\" + "cms-bundle-client.p12");
    }

    @GetMapping(value = "/cacrl")
    public @ResponseBody ResponseEntity<InputStreamResource> getCaCrl() throws IOException {
        FileInputStream in = new FileInputStream("certs\\cms-bundle-rca.crl");
        return ResponseEntity.ok()
                .contentType(MediaType.valueOf("application/pkix-crl"))
                .body(new InputStreamResource(in));
    }

    @GetMapping(value = "/imcrl")
    public @ResponseBody ResponseEntity<InputStreamResource> getImCrl() throws IOException {
        FileInputStream in = new FileInputStream("certs\\cms-bundle-ica.crl");
        return ResponseEntity.ok()
                .contentType(MediaType.valueOf("application/pkix-crl"))
                .body(new InputStreamResource(in));
    }

    @PostMapping("/sign-cert")
    public @ResponseBody ResponseEntity<byte[]> signCertificate(@RequestBody MultipartFile file, @RequestParam(defaultValue = "false") boolean raw) throws
            Exception {
        PKCS10CertificationRequest request;
        if (!raw) {
            byte[] rawCsr = fromPem(file.getBytes());
            request = new PKCS10CertificationRequest(rawCsr);
        } else {
            request = new PKCS10CertificationRequest(file.getBytes());
        }
        ASN1Sequence sequence = ASN1Sequence.getInstance(request.getSubjectPublicKeyInfo().parsePublicKey());
        ASN1Integer modulus = ASN1Integer.getInstance(sequence.getObjectAt(0));
        ASN1Integer exponent = ASN1Integer.getInstance(sequence.getObjectAt(1));
        RSAPublicKeySpec keySpec = new RSAPublicKeySpec(modulus.getPositiveValue(), exponent.getPositiveValue());
        KeyFactory factory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = factory.generatePublic(keySpec);
        X509Certificate signedCertificate =
                CertificateUtil.generateSignedCertificate(request.getSubject().toString(), List.of(request.getSubject().toString()), 365,
                        IM_CA.getCertificate(), IM_CA.getPrivateKey(), HASH_ALG, publicKey, false, false);
        return ResponseEntity.ok()
                .contentType(MediaType.valueOf("application/x-pem-file"))
                .body(signedCertificate.getEncoded());
    }
}
