package com.virsec.cms.certmgr;

import org.bouncycastle.openssl.PEMParser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.ListResourceBundle;

import static com.virsec.cms.certmgr.CertMgrApplication.ROOT_CA;
import static com.virsec.cms.certmgr.CertificateUtil.HASH_ALG;
import static com.virsec.cms.certmgr.CertificateUtil.exportPem;

@RestController
public class CertificateController {
    @GetMapping("/generate-certs")
    public void generateCerts() throws Exception {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(4096);
        KeyPair intermediateKeyPair = keyPairGenerator.generateKeyPair();
        X509Certificate intermediateCa =
                CertificateUtil.generateSignedCertificate("Virsec Intermediate CA", List.of("*.cms.virsec.com"), 365, ROOT_CA.getCertificate(),
                        ROOT_CA.getPrivateKey(), CertificateUtil.HASH_ALG, intermediateKeyPair.getPublic(), true);

        Files.write(Paths.get("cms-intermediate-ca.crt"), intermediateCa.getEncoded());
        KeyPair serverKeyPair = keyPairGenerator.generateKeyPair();
        X509Certificate serverCertificate =
                CertificateUtil.generateSignedCertificate("server.cms.virsec.com", List.of("server.cms.virsec.com"), 365, intermediateCa,
                        intermediateKeyPair.getPrivate(), CertificateUtil.HASH_ALG, serverKeyPair.getPublic(), false);
        Files.write(Paths.get("cms-server-cert.crt"), serverCertificate.getEncoded());
        exportPem(PEMParser.TYPE_CERTIFICATE, List.of(serverCertificate.getEncoded(), intermediateCa.getEncoded(), ROOT_CA.getCertificate().getEncoded()),
                "cms-bundle.pem");
        exportPem(PEMParser.TYPE_RSA_PRIVATE_KEY, List.of(serverKeyPair.getPrivate().getEncoded()), "cms-bundle.key");
        Files.write(Paths.get("cms-bundle-raw.key"), serverKeyPair.getPrivate().getEncoded());

        X509CRL emptyCRL = CertificateUtil.createEmptyCRL(intermediateKeyPair.getPrivate(), HASH_ALG, intermediateCa);
        X509CRL crl = CertificateUtil.addRevocationToCRL(intermediateKeyPair.getPrivate(), HASH_ALG, emptyCRL, serverCertificate);
        exportPem(PEMParser.TYPE_X509_CRL, List.of(crl.getEncoded()), "cms-bundle.crl");
    }
}
