package com.virsec.cms.certmgr;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.List;

import static com.virsec.cms.certmgr.CertMgrApplication.*;

public class CertificateStoreUtil {

    public static void initCA() throws Exception {
        if (!Files.exists(Path.of("certs", ROOT_CA_KEY_STORE_PATH))) {
            System.out.println("Creating new root ca store...");
            KeyStore pkcs12 = KeyStore.getInstance("PKCS12");
            pkcs12.load(null, null);
            ROOT_CA = CertificateUtil.generateRootCA("Virsec Root CA", List.of("server.cms.virsec.com", "*.cms.virsec.com", "*.virsec.com"), 365);
            pkcs12.setKeyEntry(VIRSEC_ROOT_CA, ROOT_CA.getPrivateKey(), KEY_STORE_PASSWORD.toCharArray(), new X509Certificate[]{ROOT_CA.getCertificate()});
            FileOutputStream fOut = new FileOutputStream("certs\\" + ROOT_CA_KEY_STORE_PATH);
            pkcs12.store(fOut, KEY_STORE_PASSWORD.toCharArray());
            fOut.close();
        } else {
            System.out.println("loading from local root ca store...");
            KeyStore store = KeyStore.getInstance("PKCS12");
            FileInputStream fileInputStream = new FileInputStream("certs\\" + ROOT_CA_KEY_STORE_PATH);
            store.load(fileInputStream, KEY_STORE_PASSWORD.toCharArray());
            fileInputStream.close();
            PrivateKey privateKey = (PrivateKey) store.getKey(VIRSEC_ROOT_CA, KEY_STORE_PASSWORD.toCharArray());
            Certificate certificate = store.getCertificateChain(VIRSEC_ROOT_CA)[0];
            ROOT_CA = new CmsCertificate(privateKey, privateKey.getEncoded(), (X509Certificate) certificate);
        }
        System.out.println("Loaded root ca store.");

        if (!Files.exists(Path.of("certs", IM_CA_KEY_STORE_PATH))) {
            System.out.println("Creating new im ca store...");
            KeyStore pkcs12 = KeyStore.getInstance("PKCS12");
            pkcs12.load(null, null);
            IM_CA = CertificateUtil.generateIntermediateCA("CN=Virsec Intermediate CA", List.of("server.cms.virsec.com", "*.cms.virsec.com"), 365);
            pkcs12.setKeyEntry(VIRSEC_IM_CA, IM_CA.getPrivateKey(), KEY_STORE_PASSWORD.toCharArray(), new X509Certificate[]{IM_CA.getCertificate()});
            FileOutputStream fOut = new FileOutputStream("certs\\" + IM_CA_KEY_STORE_PATH);
            pkcs12.store(fOut, KEY_STORE_PASSWORD.toCharArray());
            fOut.close();
        } else {
            System.out.println("loading from local im ca store...");
            KeyStore store = KeyStore.getInstance("PKCS12");
            FileInputStream fileInputStream = new FileInputStream("certs\\" + IM_CA_KEY_STORE_PATH);
            store.load(fileInputStream, KEY_STORE_PASSWORD.toCharArray());
            fileInputStream.close();
            PrivateKey privateKey = (PrivateKey) store.getKey(VIRSEC_IM_CA, KEY_STORE_PASSWORD.toCharArray());
            Certificate certificate = store.getCertificateChain(VIRSEC_IM_CA)[0];
            IM_CA = new CmsCertificate(privateKey, privateKey.getEncoded(), (X509Certificate) certificate);
        }
        System.out.println("Loaded im ca store.");
    }


    public static void createP12KeyStore(String alias, PrivateKey privateKey, X509Certificate[] chain, String filename) throws Exception {
        KeyStore pkcs12 = KeyStore.getInstance("PKCS12");
        pkcs12.load(null, null);
        pkcs12.setKeyEntry(alias, privateKey, KEY_STORE_PASSWORD.toCharArray(), chain);
        FileOutputStream fOut = new FileOutputStream(filename);
        pkcs12.store(fOut, KEY_STORE_PASSWORD.toCharArray());
        fOut.close();
    }

    public static void createP12TrustStore(String alias, X509Certificate[] chain, String filename) throws Exception {
        KeyStore pkcs12 = KeyStore.getInstance("PKCS12");
        pkcs12.load(null, null);
        pkcs12.setCertificateEntry(alias, chain[0]);
        pkcs12.setCertificateEntry(alias+"1", chain[1]);
        FileOutputStream fOut = new FileOutputStream(filename);
        pkcs12.store(fOut, KEY_STORE_PASSWORD.toCharArray());
        fOut.close();
    }
}
