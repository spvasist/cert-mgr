package com.virsec.cms.certmgr;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.List;

import static com.virsec.cms.certmgr.CertMgrApplication.*;

public class CertificateStoreUtil {

    public static void initRootCA() throws Exception {
        if (!Files.exists(Path.of(ROOT_CA_KEY_STORE_PATH))) {
            System.out.println("Creating new store...");
            KeyStore pkcs12 = KeyStore.getInstance("PKCS12");
            pkcs12.load(null, null);
            ROOT_CA = CertificateUtil.generateRootCA("Virsec Root CA", List.of("server.cms.virsec.com", "*.cms.virsec.com", "*.virsec.com"), 365);
            pkcs12.setKeyEntry(VIRSEC_ROOT_CA, ROOT_CA.getPrivateKey(), KEY_STORE_PASSWORD.toCharArray(), new X509Certificate[]{ROOT_CA.getCertificate()});
            FileOutputStream fOut = new FileOutputStream(ROOT_CA_KEY_STORE_PATH);
            pkcs12.store(fOut, KEY_STORE_PASSWORD.toCharArray());
            fOut.close();
        } else {
            System.out.println("loading from local store...");
            KeyStore store = KeyStore.getInstance("PKCS12");
            FileInputStream fileInputStream = new FileInputStream(ROOT_CA_KEY_STORE_PATH);
            store.load(fileInputStream, KEY_STORE_PASSWORD.toCharArray());
            fileInputStream.close();
            PrivateKey privateKey = (PrivateKey) store.getKey(VIRSEC_ROOT_CA, KEY_STORE_PASSWORD.toCharArray());
            Certificate certificate = store.getCertificateChain(VIRSEC_ROOT_CA)[0];
            ROOT_CA = new CmsCertificate(privateKey, privateKey.getEncoded(), (X509Certificate) certificate);
        }
        System.out.println("Loaded root ca store.");
    }

}
