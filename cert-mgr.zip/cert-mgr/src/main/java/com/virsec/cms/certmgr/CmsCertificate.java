package com.virsec.cms.certmgr;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CmsCertificate {
    private PrivateKey privateKey;
    private byte[] privateKeyEncoded;
    private X509Certificate certificate;

    public void saveCertificateCer(Path path) throws CertificateEncodingException, IOException {
        Files.write(path, certificate.getEncoded());
    }
}
